/**
 * SparkP2P Content Script — Binance API Executor
 *
 * Runs on Binance pages. Makes all Binance C2C API calls using the
 * browser's own credentials (cookies sent automatically via
 * credentials: 'include'). This ensures requests come from the
 * user's IP, not the VPS.
 *
 * The background script orchestrates; this script executes.
 */

(() => {
  'use strict';

  console.log('[SparkP2P] Content script loaded on', window.location.href);

  // ── Message handler ────────────────────────────────────────────

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

    // Generic Binance API request
    if (msg.type === 'BINANCE_REQUEST') {
      makeBinanceRequest(msg.endpoint, msg.payload)
        .then(data => sendResponse({ success: true, data }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true; // async response
    }

    // Custom URL Binance request (for non-C2C endpoints like wallet balance)
    if (msg.type === 'BINANCE_REQUEST_CUSTOM') {
      makeCustomRequest(msg.url, msg.payload)
        .then(data => sendResponse({ success: true, data }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }

    // Ping — check if content script is alive
    if (msg.type === 'PING') {
      sendResponse({ alive: true, url: window.location.href });
      return false;
    }

    // Get page cookies (for cookie sync)
    if (msg.type === 'GET_PAGE_COOKIES') {
      sendResponse({ cookies: document.cookie });
      return false;
    }
  });

  // ── Binance API caller ─────────────────────────────────────────

  async function makeBinanceRequest(endpoint, payload) {
    // Use the CURRENT page's origin to avoid CORS issues
    // p2p.binance.com and c2c.binance.com both serve the same C2C API
    const baseUrl = window.location.origin;
    const url = `${baseUrl}/bapi/c2c/v2/private${endpoint}`;

    const resp = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Clienttype': 'web',
        'C2ctype': 'c2c_web',
      },
      body: JSON.stringify(payload || {}),
      credentials: 'include',  // Browser sends all cookies automatically
    });

    if (resp.status === 401 || resp.status === 403) {
      throw new Error(`Binance session expired (HTTP ${resp.status})`);
    }

    const data = await resp.json();

    // Binance returns {"code": "000000", "data": {...}} on success
    if (data.code && data.code !== '000000') {
      throw new Error(`Binance API error ${data.code}: ${data.message || 'Unknown'}`);
    }

    return data;
  }

  async function makeCustomRequest(url, payload) {
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload || {}),
      credentials: 'include',
    });
    return await resp.json();
  }

  // ── Notify background that content script is ready ─────────────

  chrome.runtime.sendMessage({ type: 'CONTENT_SCRIPT_READY', url: window.location.href });

})();
